%% Script for running PMA using the grid-search algorithm 

clear all; close all

datafile = sprintf('TEST1.mat'); % If exists, will be loaded; if not, will be created
datafolder = sprintf('events');
outputfolder = sprintf('Twin_1'); % MAKE THIS IF IT DOESN'T EXIST
figuresfolder = sprintf('FIGURES'); % MAKE THIS IF IT DOESN'T EXIST
freqplotsfolder = sprintf('FREQ_PLOTS'); 
gridplotsfolder = sprintf('GRID_PLOTS'); % MAKE THIS IN OUTPUTFOLDER IF IT DOESN'T EXIST

twin = 1;           % seconds after P-wave onset (defined by tshift)
                                          
fid2 = fopen('events.txt','r');
Input = textscan(fid2,'%s');
events = Input{1};
fclose(fid2);


% LOAD ALL DATA
if exist(datafile) == 0;
    for m = 1:length(events)
        disp(sprintf('Loading event %0.0f of %0.0f',m,length(events)))
        event = events{m};
        listall = dir(strcat('../',datafolder,'/',event,'/*.i.*.picked')); %change path if needed
        listtmp = struct2cell(listall);
        list = listtmp(1,:)';
        listtoread = strcat('../',datafolder,'/',event,'/',list); %change path if needed
        list_order = natsortfiles(listtoread);   
        DATA = read_sacfiles_string(list_order);
        if m == 1
            ALL_DATA = DATA;
        else
            ALL_DATA = [ALL_DATA; DATA];
        end
    end
    disp(sprintf('Saving data to %s',datafile))
    save(datafile,'ALL_DATA','-v7.3')
elseif exist(datafile) == 2;
    disp(sprintf('Loading data from %s',datafile))
    load(datafile);
end


% GET UNIQUE LIST OF STATIONS TO LOOP OVER
STAS = unique(sort(ALL_DATA(:,2)));

for i = 1;%1:size(STAS,1);  

    STAS(i)
    
    ind_sta = strcmp(STAS(i),ALL_DATA(:,2));
    STA_DATA = ALL_DATA(ind_sta,:);
    STALAT = STA_DATA(1,8); % assuming your station doesn't move...
    STALON = STA_DATA(1,7); % assuming your station doesn't move...
    EVENTS = unique(sort(STA_DATA(:,1)));
    
 
    
    % RUN SUNNY ALGORITHM(PCA)
    
    for j = 1:size(EVENTS,1);
            % Get waveform
            ind_event = strcmp(EVENTS(j),STA_DATA(:,1));
            EVENT_DATA = STA_DATA(ind_event,:);
            
            indz = strcmp('z',EVENT_DATA(:,3));
            indr = strcmp('r',EVENT_DATA(:,3));
            
            Z = EVENT_DATA{indz,4}(:,2);
            %timeR = EVENT_DATA{indr,4}(:,1);
            R = EVENT_DATA{indr,4}(:,2);
            rayp = EVENT_DATA{indz,5};
            Ptime = EVENT_DATA{indz,9};
            dt = round(EVENT_DATA{indz,6}*10^3)/10^3;
            %timeZ = [-tshift+dt:dt:(length(Z)*dt)-tshift]; 
            timeZ = EVENT_DATA{indz,4}(:,1);
            
            
            %calculated predicted Vs
          
            % Time window
            Zwin = Z(timeZ>=Ptime & timeZ<=twin+Ptime); %v_obs
            Rwin = R(timeZ>=Ptime & timeZ<=twin+Ptime); %r_obs
            Twin = timeZ(timeZ>=Ptime & timeZ<=twin+Ptime); %time window
            
            % PCA and eigenvector calculation
            [pca_comps,score] = pca([Rwin,Zwin],'Algorithm','eig');
            
            % PCA Method as outlined in Park and Ishii 2018
            X = [Rwin-mean(Rwin) Zwin-mean(Zwin) ];
            C = (X'*X)/length(Zwin);
            [Vman,vman] = eig(C);
            vman = nonzeros(vman); % drop zeros from eigenvalue matrix
            l1 = max(vman);
            l1_loc = find(vman==l1); %largest eigenvalue
            Vman_l1 = Vman(:,l1_loc); 
            l2 = min(vman);
            l2_loc = find(vman==l2); %smallest eigenvalue
            Vman_l2 = Vman(:,l2_loc);
            deg_linear = l1/sum(vman); % weighting metric (total variance explained by major particle motion)

            % Solve for angle of 1st principle component
            %theta = atand(pca_comps(1,1)./pca_comps(1,2));
            theta_pca = acosd(Vman_l1(2)/sqrt(sum(Vman_l1.^2))); % different from index in Park bc of rearrange Z,R in martrix
            if theta_pca > 90
                theta_pca = 180 - theta_pca;
            end
            Vs_pca = sind(theta_pca/2)/rayp;
            
            
            
            %% Grid-search Algorithm
            
            %rotate through angles and try to calculate misfit "verticalness"
            line = linspace(-max(Zwin)*1.2,max(Zwin)*1.2,100); %array with max amplitude as that of Zwin
            other = zeros(size(line));
            vert = [other;line]; %initial vertical line
            horz = [line;other]; %initial horizontal line
            theta = -45:0.01:-0.001; %search angles
            cum_ete = zeros(size(theta)); %array to store cumulative misfit
            m_horz = zeros(size(theta)); %array to store the slope of each horizontal line when rotated
            m_vert = zeros(size(theta)); %array to store the slope of each vertical line when rotated

            %loop over angles
            for k = 1:length(theta)
                rotmat = [cosd(theta(k)) -sind(theta(k)); sind(theta(k)) cosd(theta(k))]; %define the rotation matrix
                vertrot = rotmat*vert; %rotate the vertical
                horzrot = rotmat*horz; %rotate the horizontal
                m_vert(k) = (max(vertrot(2,:))-min(vertrot(2,:)))/(max(vertrot(1,:))-min(vertrot(1,:))); %calculate slope of the rotated vertical
                m_horz(k) = (min(horzrot(2,:))-max(horzrot(2,:)))/(max(horzrot(1,:))-min(horzrot(1,:))); %calculate slope of the rotated horizontal
                disp(m_vert(k))
                disp(tan(theta(k)))
                % calculate misfit
                ete_v = sum(((Zwin - m_vert(k).*Rwin).*Zwin).^2);  % weighting by amplitude to total misfit
                ete_h = sum(((Zwin - m_horz(k).*Rwin).*Zwin).^2);  % weighting by amplitude to total misfit
            
                cum_ete(k) = ete_v+ete_h;
                
            end
            ete_min_idx = find(cum_ete == min(cum_ete));
            theta_grid = theta(ete_min_idx);
            Vs_grid = sind(-theta_grid/2)/rayp;
                

            if (0 > theta_grid) & (theta_grid > -20);
                status = 1;
            else
                status = 0;
            end
          
            %% Calculate the uncertainty in the measurements

            if status == 1;
            
                conf_int = 5/100; %we accept 5% uncertainty

                ete_min = min(cum_ete);
                ete_q = (1+conf_int) * ete_min;

                % Find the indices where y_data matches y_val within a tolerance
                tolerance = 1e-6; % Adjust the tolerance as necessary
                indices = find(abs(cum_ete - ete_q) < tolerance);

                theta_qs = [];
                % Check for exact matches and interpolate between points if needed
                for m = 1:length(cum_ete)-1
                    % Check if y_val lies between y_data(i) and y_data(i+1)
                    if (cum_ete(m) - ete_q) * (cum_ete(m+1) - ete_q) <= 0
                        % Interpolate to find the exact x value
                        x_interp = interp1(cum_ete(m:m+1), theta(m:m+1), ete_q);
                        theta_qs = [theta_qs, x_interp];
                    end
                end
                
                sz = length(theta_qs);

                if sz == 2;
                    left_unc = abs(abs(theta_grid) - abs(theta_qs(1:1)));
                    right_unc = abs(abs(theta_grid) - abs(theta_qs(2:2)));

                    left_Vs_unc = (1/(2*rayp))*(cosd(-theta_grid/2))*left_unc;
                    right_Vs_unc = (1/(2*rayp))*(cosd(-theta_grid/2))*right_unc;
                else
                    left_unc = NaN;
                    right_unc = NaN

                    left_Vs_unc = NaN;
                    right_Vs_unc = NaN;
                end

            else

                left_unc = 0;
                right_unc = 0;

                left_Vs_unc = 0;
                right_Vs_unc = 0;                
            end
           
            
            
            %% Plotting
            
            figure(1)
            subplot(2,2,1)
            plot(Twin,Zwin','k')
            hold on
            scatter(Twin,Zwin',25,Twin,'filled')
            ylabel('Vertical (Z)')
            xlabel('Time (s)')
            subplot(2,2,3)
            plot(Twin,Rwin','k')
            hold on
            scatter(Twin,Rwin',25,Twin,'filled')
            ylabel('Radial (R)')
            xlabel('Time (s)')
            subplot(2,2,2)
            scatter(Rwin'/max(Zwin),Zwin'/max(Zwin),25,Twin,'filled')
            hold on
            axis equal
            ylabel('Vertical Motion')
            xlabel('Radial Motion')
            subplot(2,2,4)
            scatter(Rwin/max(Zwin),Zwin/(max(Zwin)),25,Twin,'filled')
            hold on
            plot([0,Vman_l1(1)],[0,Vman_l1(2)])
            plot([0,Vman_l2(1)*l2/l1],[0,Vman_l2(2)*l2/l1]) % scaled by small/large eigenvalue
            axis equal
            ylabel('Vertical Motion')
            xlabel('Radial Motion')
            legend('','Observed','','Predicted')
            title('PCA analysis')
  
            %

            figure(2) % Plot full waveforms
            %plot(Twin,Zwin','k')
            tplot = timeZ(1:310)
            Zplot = Z(1:310)
            Rplot = R(1:310)
            plot(tplot,Zplot,'k');
            hold on
            %plot(Tin,Rwin','r')
            plot(tplot,Rplot,'r');
            hold on
            xline(Ptime,'-',{'P arrival'});
            legend('vertical','radial')
            filename1 = strcat('./RESULTS','/',outputfolder,'/',gridplotsfolder,'/',STAS(i),"_",EVENTS(j),'_P-wave.png')
            saveas(gcf,char(filename1),'png');

            figure(3)
            %sgtitle('Gridsearch approach')
            subplot(1,2,1)
            scatter(Rwin,Zwin)
            hold on
            axis equal
            ylabel('Vertical')
            xlabel('Radial')
            plot(Rwin,m_vert(ete_min_idx).*Rwin)
            plot(Rwin,m_horz(ete_min_idx).*Rwin)
            legend('data','bestfit','bestfit orth')
            subplot(1,2,2)
            plot(theta(theta<-1),cum_ete(theta<-1))
            hold on
            scatter(theta_grid,min(cum_ete),50,'filled','r')
            ylabel('Misfit')
            xlabel('Angle')
            ylim([0 20*(min(cum_ete))])
            title('Weighted Misfit')
            filename2 = strcat('./RESULTS','/',outputfolder,'/',gridplotsfolder,'/',STAS(i),"_",EVENTS(j),'_gridsearch.png')
            saveas(gcf,char(filename2),'png');
                    
            
            %Finding the dominant frequency
            Fs = 1/dt; % sampling frequency
            Zfilt = time_taper(Z,dt,7);
            x = Zfilt - mean(Zfilt);
            N = length(x);
            nfft = 2^ceil(log2(N)); % next larger power of 2
            y = fft(x,nfft); % Fast Fourier Transform
            y = abs(y.^2); % raw power spectrum density
            y = y(1:1+nfft/2); % half-spectrum
            [a,b] = max(y); % find maximum
            f_scale = (0:nfft/2)* Fs/nfft; % frequency scale
            fest = f_scale(b); % dominant frequency estimate
            fprintf('Dominant freq.: true %f Hz, estimated %f Hznn\n', fest, fest)
            fprintf('Frequency step (resolution) = %f Hznn\n', f_scale(2))
            
            figure;
            plot(f_scale, y),axis('tight'),grid('on'),title('Dominant Frequency')
            ylabel('Amplitude')
            xlabel('Frequency (Hz)')
            filename3 = strcat('./RESULTS','/',outputfolder,'/',freqplotsfolder,'/',STAS(i),"_",EVENTS(j),'_freq.png')
            saveas(gcf,char(filename3),'png');
            
            close all;
            
            %% Outputs/inputs
            
            
            solns(j,1) = theta_pca;
            solns(j,2) = Vs_pca;
            solns(j,3) = deg_linear;
            solns(j,4) = theta_grid;
            solns(j,5) = Vs_grid;
            solns(j,6) = status;
            solns(j,7) = fest;
            solns(j,8) = left_unc;
            solns(j,9) = right_unc;
            solns(j,10) = left_Vs_unc;
            solns(j,11) = right_Vs_unc;
            
            Vs_solns = solns
            
    
    end          
    
    %SAVE RESULTS
    fid = strcat('./RESULTS','/',outputfolder,'/',STAS(i),'_Vs_freq_results.mat');
    save(char(fid),'Vs_solns','STALON','STALAT');
    clear solns Vs_solns STALON STALAT
    close all;    
    
    
end


