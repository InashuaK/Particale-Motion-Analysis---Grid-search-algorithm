%Getting the elevations from DEM data
clear all; close all;

figuresfolder = sprintf('PLOTS'); % MAKE THIS IF IT DOESN'T EXIST
outputfolder = sprintf('RESULTS');% MAKE THIS IF IT DOESN'T EXIST

%%Reads a .hgt(SRTM) DEM

dir_path = '/depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/TOPO/DEM/'; %change this path accordingly

demFiles = dir(fullfile(dir_path, '*.hgt' ));

elevations = [];
latitudes = [];
longitudes = [];


for k = 1:length(demFiles);
    baseFilename = demFiles(k).name;
    filename = fullfile(dir_path, baseFilename);
    % File path to the .hgt file
    %filepath = './depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/TOPO/DEM/N44W123.hgt';
    
    % Define grid resolution and size
    arcseconds_per_degree = 3600; % Number of arcseconds in a degree
    resolution_arcseconds = 3; % Resolution in arcseconds
    gridSize = arcseconds_per_degree / resolution_arcseconds + 1; % 1201 for 1-arcsecond
    
    % Extract the southwestern corner coordinates from the file name
    
    latitude_sw = str2double(extractBetween(baseFilename, 'N', 'W')); % Positive for northern hemisphere
    longitude_sw = str2double(extractBetween(baseFilename, 'W','.')); % Negative for western hemisphere
    longitude_sw = -longitude_sw;

    % Read the elevation data from the .hgt file
    fileID = fopen(filename, 'r', 'ieee-be');
    if fileID == -1
    error('Error opening the .hgt file.');
    end
    
    % Read the elevation data as 16-bit signed integers
    elevationData = fread(fileID, [gridSize, gridSize], 'int16');
    fclose(fileID);
    
    % Flip the data in the vertical direction to align with geographical orientation
    elevationData = flipud(elevationData);
    
    % Create a grid of latitudes and longitudes
    % Each row represents a different latitude
    % Each column represents a different longitude
    
    % Generate latitude values
    lat = linspace(latitude_sw + 1, latitude_sw, gridSize);
    
    % Generate longitude values
    lon = linspace(longitude_sw, longitude_sw + 1, gridSize);
    
    % Create a meshgrid for latitude and longitude
    [latGrid, lonGrid] = meshgrid(lat, lon);
    
    
    % Create a table with columns for latitude, longitude, and elevation
    numPoints = numel(elevationData);
    temp_latitudes = reshape(latGrid, numPoints, 1);
    temp_longitudes = reshape(lonGrid, numPoints, 1);
    temp_elevations = reshape(elevationData, numPoints, 1);

    latitudes = [latitudes; temp_latitudes];
    longitudes = [longitudes; temp_longitudes];
    elevations = [elevations; temp_elevations];

end

DATA_deg = [latitudes, longitudes, elevations];
datafile1 = sprintf('./DATA_deg.mat')
save(datafile1,'DATA_deg','-v7.3')

latpoints =  length(latitudes);
Eastings = zeros(numPoints, 1);
Northings = zeros(numPoints, 1);
Zones = zeros(numPoints, 1);
datafile = sprintf('./DATA_utm.mat');
% Loop over all points
if exist(datafile) == 0;

    for i = 1:latpoints
        [Northings, Eastings, Zones] = deg2utm(latitudes(i), longitudes(i));
    
        DATA_utm(i,1) = Northings;
        DATA_utm(i,2) = Eastings;
    end
    disp(sprintf('Saving data to %s',datafile))
    save(datafile,'DATA_utm','-v7.3')
elseif exist(datafile) == 2;
    disp(sprintf('Loading data from %s',datafile))
    load(datafile);
end

% Display the sizes of the resulting arrays
fprintf('Total data points: %d\n', length(elevations));
fprintf('Size of latitudes: %d\n', length(latitudes));
fprintf('Size of longitudes: %d\n', length(longitudes));