%Estimating the depth range using Park 2019
figuresfolder = sprintf('Depth_PLOTS'); % MAKE THIS IF IT DOESN'T EXIST
clear all;

fid = fopen('/depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/PMA_Method/TOPO/RESULTS/TOPO_corrections/2.0_topo_results.txt','r');
Input = textscan(fid,'%s');  % Read floats, strings, integers
fclose(fid);
list=Input{1};

for i = 1;%1:length(list);
    filename = list{i};
    file_path = '/depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/PMA_Method/TOPO/RESULTS/TOPO_corrections/'
    file = fullfile(file_path,filename)
    load(file);

        DATA = result;
        %data = sortrows(DATA,7);

        delimiter = "_";
        parts = split(filename, delimiter);
        Sta = parts{2};
        
        if size(DATA,1) > 1
            data = sortrows(DATA,6); %sort data based on freq
            Vs_values = data(:, 8);
            freq_values = (data(:, 6));
            %window_size = 3;
            %moving_avg_freq = movmean(freq_values, window_size);
            lambda = data(:, 5);
            theta = data(:, 4);
            Depth = (lambda/2);
        else
            Vs_values = DATA(:, 8);
            freq_values = (DATA(:, 6));
            %window_size = 4;
            %moving_avg_freq = movmean(freq_values, window_size);
            lambda = DATA(:, 5);
            theta = DATA(:, 4);
            Depth = (lambda/2);

        end
    
        Output = [];
        Output = [Output; Vs_values,freq_values,lambda,Depth];  
    

        %SAVE RESULTS
        fid2 = strcat('/depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/PMA_Method/TOPO/RESULTS/TOPO_corrections/','2.0_',Sta,'_Vs_notilt_depth.mat');
        save(char(fid2),'Output');
        clear Output;        
    
end
    
