%% Import Sac Files and Create array of data

function OUTPUT = read_sacfiles_string(list)
    

for i = 1:length(list)
    SacFile=char(list(i));
    tmp = strsplit(SacFile,'/');
    evnm = tmp{1,3};
    tmp2 = strsplit(tmp{1,4},'_');
    %stnm = tmp2{1,1};
    tmp3 = strsplit(tmp2{1,2},'.');
    %stnm = strcat(tmp2{1,1},'.',tmp3{1,3});
    cmp = tmp3{1,4};
%    txtfile=list(i);
%fname = sprintf('Migrated2Depth.txt');
%fidout = fopen(fname,'w');

% Byte-order of the SAC file is checked
%--------------------------------------------------------------------------
fid = fopen(SacFile,'r','ieee-be');
fread(fid,70,'single');
fread(fid,6,'int32');
NVHDR = fread(fid,1,'int32');
fclose(fid);
if (NVHDR == 4 || NVHDR == 5)
    message = strcat('NVHDR = 4 or 5. File: "',SacFile,'" may be from an old version of SAC.');
    error(message)
elseif NVHDR ~= 6
    endian = 'ieee-le';
elseif NVHDR == 6
    endian = 'ieee-be';
end



fid = fopen(SacFile,'r',endian);
% Read in the header information to junk
%--------------------------------------------------------------------------
junk = fread(fid,1,'single');
fread(fid,4,'single');
junk = fread(fid,1,'single');
fread(fid,64,'single');
fread(fid,9,'int32');
junk = fread(fid,1,'int32');
fread(fid,25,'int32');
junk = fread(fid,1,'int32');
fread(fid,4,'int32');
fread(fid,192,'char');

% Read in the amplitude information
%--------------------------------------------------------------------------
Amps = fread(fid,'single');
fclose(fid);



% Read Headers
fid = fopen(SacFile,'r',endian);
% For headers locations, visit http://www.iris.edu/software/sac/manual/file_format.html
            % open sac file and add header information
            %--------------------------------------------------------------
            TimeDelta = fread(fid,1,'single');
            fread(fid,4,'single');
            BeginTime = fread(fid,1,'single');
            fread(fid,5,'single');
            t1=fread(fid,1,'single');
            fread(fid,19,'single');
            stalat=fread(fid,1,'single'); %slat = fread(fid,1,'single'); %StaLat
            stalon=fread(fid,1,'single'); %slon = fread(fid,1,'single'); %StaLon
            fread(fid,1,'single'); %StaElv = fread(fid,1,'single') / 1000; %StaElev (km)
            fread(fid,1,'single');
            evla=fread(fid,1,'single'); %elat = fread(fid,1,'single'); %EvLat
            evlo=fread(fid,1,'single'); %elon = fread(fid,1,'single'); %EvLon
            fread(fid,1,'single');
            evdp = fread(fid,1,'single'); % EvDepth = fread(fid,1,'single'); %EvDepth (km)
            fread(fid,1,'single'); %EvMag = fread(fid,1,'single'); %EvMag
            fread(fid,1,'single'); %USER0, Gaussian of RF
            fread(fid,3,'single');
            rayp = fread(fid,1,'single'); %USER4, RayP
            fread(fid,3,'single');
            fread(fid,1,'single'); %PreStatus = fread(fid,1,'single'); %USER8 (Predetermined Status within SAC file)
            fread(fid,1,'single'); %RadFit = fread(fid,1,'single'); %USER9
            %if RadFit == -12345
            %    RadFit = NaN;
            %end
            fread(fid,1,'single');
            fread(fid,1,'single');
            baz = fread(fid,1,'single'); %baz = fread(fid,1,'single'); %Baz
            dist = fread(fid,1,'single'); %DistDeg = fread(fid,1,'single'); %DistDeg
            fread(fid,5,'single');
            fread(fid,20,'int32');
            SampleCount = fread(fid,1,'int32');
            fread(fid,30,'int32');
            
            % GET STATION NAME, CMP, AND NETWORK DIRECTLY FROM SAC FILE
            StationName = deblank(char(fread(fid,8,'char')'));
            fread(fid,16,'char');
            %cmpname = deblank(char(fread(fid,8,'char')')); %khole 
            cmpname = deblank(char(fread(fid,8,'char')')); %khole 
            %fread(fid,1,'char',151)
            fread(fid,136,'char');
            NetworkName = deblank(char(fread(fid,8,'char')'));
            
            fclose(fid);
            
            if cmpname ~= 12345
                stnm = [NetworkName '.' StationName '.' cmpname];
            else
                stnm = [NetworkName '.' StationName];
            end
            %

TimeAxis = [BeginTime:TimeDelta:BeginTime+(TimeDelta*SampleCount-TimeDelta)]';
SACS{i} = [TimeAxis, Amps];

OUTPUT{i,1} = evnm;
OUTPUT{i,2} = stnm;
OUTPUT{i,3} = cmp;
OUTPUT{i,4} = SACS{i};
OUTPUT{i,5} = rayp;
OUTPUT{i,6} = TimeDelta;
OUTPUT{i,7} = stalon;
OUTPUT{i,8} = stalat;
OUTPUT{i,9} = t1;
OUTPUT{i,10} = baz;
OUTPUT{i,11} = evdp;
OUTPUT{i,12} = dist;
OUTPUT{i,13} = evlo;
OUTPUT{i,14} = evla;

end

            
            
            
            