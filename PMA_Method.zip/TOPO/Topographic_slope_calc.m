
clear all; close all;

figuresfolder = sprintf('PLOTS'); % MAKE THIS IF IT DOESN'T EXIST
outputfolder = sprintf('RESULTS');% MAKE THIS IF IT DOESN'T EXIST
%%calculate distance from stations
% loop over stations
fid1 = fopen('results.txt','r');
Input = textscan(fid1,'%s');
results = Input{1};
fclose(fid1);

for i = 1;%1:size(results,1);
    file = results{i};
    path = '/depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/PMA_Method/RESULTS/Twin_1'; %change this path accordingly
    filepath = fullfile(path,file);
    load(filepath);
    
    %calculate Fresnel radius for a particular station
    med_freq = median(Vs_solns(:,7));
    med_vs = median(Vs_solns(:,5));

    fres_rad_km = med_vs/(2*med_freq);
    fres_rad = fres_rad_km * 1000;

    %getting station locations
    stla = cell2mat(STALAT);
    stlo = cell2mat(STALON);
    [North_sta, East_sta, Zone_sta] = deg2utm(stla,stlo);

    %looping over DEMS
    demdatapath = '/depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/PMA_Method/TOPO'
    dem_deg = dir(fullfile(demdatapath,'DATA_deg*.mat'));
    dem_utm = dir(fullfile(demdatapath,'DATA_utm*.mat'));

    filt_latitudes = [];
    filt_longitudes = [];
    filt_elevations = [];

    for k = 1:length(dem_deg);
        demdegname = dem_deg(k).name;
        demutmname = dem_utm(k).name;
        data_deg = load(demdegname);
        data_utm = load(demutmname);
        fields_deg = fieldnames(data_deg);
        fields_utm = fieldnames(data_utm);
        deg_matrix = data_deg.(fields_deg{1});
        utm_matrix = data_utm.(fields_utm{1});

        elevations = deg_matrix(:,3);

        %define matrices
        ele_loc = [(utm_matrix(:,1)), (utm_matrix(:,2))];
        sta_loc = [North_sta, East_sta];
        
        diff = ele_loc - sta_loc; 
        dist = sqrt(sum((diff .^ 2),2));
        %dist = 6378.8 * (acos((sin(lat1) * sin(lat2)) + cos(lat1) * cos(lat2) .* cos(long2 - long1)));
    
        DATA = [utm_matrix, elevations, dist];
        DATA_fres = DATA(DATA(:,4) < fres_rad,:); %change corresponding to Fresnel radius
    
        fres_latitudes = DATA_fres(:,1);
        fres_longitudes = DATA_fres(:,2);
        fres_elevations = DATA_fres(:,3);

        filt_latitudes = [filt_latitudes;fres_latitudes];
        filt_longitudes = [filt_longitudes;fres_longitudes];
        filt_elevations = [filt_elevations;fres_elevations];

    end
    %%calculate least squares in 3D 
    
    %create the design/A matrix
    A = [filt_latitudes, filt_longitudes, ones(size(filt_latitudes))];
   
    %perform least square fitting
    coefficients = A \ filt_elevations;
    
    %extract the coefficients
    a = coefficients(1);
    b = coefficients(2);
    c = coefficients(3);
    
    %calculate the dip angle 
    
    n1 = [a b 1]; % Normal vector to plane
    
    n2= [0 0 1]; % normal vector to horizontal plane
    
    cosang = dot(n1,n2); %  n1.n2 = |n1||n2|cosang
    dip_angle= acosd(cosang / (norm(n1)*norm(n2)));

    % Calculate the dip direction
    azimuth = (atan2(b, a) * (180 / pi)); % Convert from radians to degrees
    dip_direction = mod(azimuth + 180, 360);
    
    % Calculate the strike
    strike = mod(dip_direction - 90, 360);

   
    %Create a mesh grid for visualization
    [X, Y] = meshgrid(linspace(min(filt_latitudes), max(filt_latitudes), 10), linspace(min(filt_longitudes), max(filt_longitudes), 10));
    Z = a * X + b * Y + c;
    
    %exaggerate longitude for plotting
    exag_factor = 10;
    exag_long = filt_longitudes * exag_factor;
    
   
    %Plotting
    
    figure;
    scatter3(filt_latitudes, filt_longitudes, filt_elevations, 'filled');
    xlabel('Lat');
    ylabel('Lon');
    zlabel('Ele');
    hold on;
    
    surf(X, Y, Z, 'FaceAlpha', 0.5);
    title('Fitted Plane to 3D Points');
    xlabel('Lat');
    ylabel('Lon');
    zlabel('Ele');
    %daspect([1 1 1])
    set(gca, 'XDir', 'reverse');
    grid on;
    hold on;
    axis equal
    
   
    %save figure
    staname = extractBefore(results{i}, '_');
    figname = strcat('./',figuresfolder,'/',staname,'_','topo','.png')
    saveas(gcf,char(figname),'png');
    

    %save output
    output = [strike, dip_angle, dip_direction];
    fid2 = strcat('./',outputfolder,'/',staname,'_topo_results_new.mat');
    save(char(fid2),'output');
    clear output;
    close all; 
end