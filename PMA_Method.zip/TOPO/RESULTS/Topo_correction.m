%%Script to apply topography correction on Vs estimates
clear all; close all;

%create directories to save results and plots
outputfolder = sprintf('TOPO_corrections'); % MAKE THIS IF IT DOESN'T EXIST
figuresfolder = sprintf('TOPO_corrections_2.0_plots');

%assign Vp/Vs ratio
Vs_true = 2.8;
vel_ratio = 2;
Vp_true = vel_ratio * Vs_true;

%Loading the station and events data
path = '/depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/PMA_Method';
datafile = 'TEST1.mat';
filepath = fullfile(path,datafile);
load(filepath);

STAS = unique(sort(ALL_DATA(:,2)));

%Looping over all stations
for i = 1%1:size(STAS,1)
    %if i == 40
       % continue
   % end

    STAS(i)
    
    ind_sta = strcmp(STAS(i),ALL_DATA(:,2));
    STA_DATA = ALL_DATA(ind_sta,:);
    STALAT = STA_DATA(1,8); % assuming your station doesn't move...
    STALON = STA_DATA(1,7); % assuming your station doesn't move...
    EVENTS = unique(sort(STA_DATA(:,1)));

    %Loading the topography data (output of Topography_test.m). The data is
    %in the variable "output"
    topo_path = '/depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/PMA_Method/TOPO/RESULTS/';
    topofile = char(strcat(STAS(i),'_topo_results_new.mat'));
    topofile_path = fullfile(topo_path, topofile);
    load(topofile_path);


    %Getting the strike, dip(or tilt), dip direction and updip of a station
    strike = output(1:1);
    tilt = output(2:2);
    dip_dir = output(3:3);
    updip = dip_dir + 180;
    if updip > 360
        updip = updip - 360;
    end

    %plot error line for a specific theta
    theta = 17;
    az_vals = [0:1:360];
    for l = 1:length(az_vals);
            az = az_vals(l);
            
            %define m
        
            z = [0,0,1];
            m_sqr = (sind(theta)*sind(az-(updip)))^2 + (cosd(theta)*sind(tilt) + sind(theta)*cosd(az-(updip))*cosd(tilt))^2;
            m = sqrt(m_sqr);
            
        
            R = (1/m)*[cosd(theta)*sind(tilt)*cosd(tilt)+sind(theta)*cosd(az-(updip))*(cosd(tilt))^2, -sind(theta)*sind(az-(updip))*cosd(tilt), m*sind(tilt); sind(theta)*sind(az-(updip)), cosd(theta)*sind(tilt)+sind(theta)*cosd(az-(updip))*cosd(tilt), 0;
                    -cosd(theta)*(sind(tilt))^2 - sind(theta)*cosd(az-(updip))*sind(tilt)*cosd(tilt), sind(theta)*sind(az-(updip))*sind(tilt), m*cosd(tilt)];

            theta_app_rot = 2*asind((Vs_true*m)/Vp_true);
            Mp = [sind(theta_app_rot);0;-cosd(theta_app_rot)];
            
            Rot_Mp = R*Mp;
            theta_app = acosd(dot(Rot_Mp,-z'));
            
            B = cosd(theta)*sind(tilt) + sind(theta)*cosd(az)*cosd(tilt);
            
            %solving for Vs_notilt
            Vs_notilt_test = sind(theta_app/2)/(sind(theta)/Vp_true);
            
            error_test = ((Vs_notilt_test - Vs_true)/Vs_true);
        
            
            %outputs
            output_test(l,1) = az;
            output_test(l,2) = error_test;
    end
    
    %create lists to append baz, az, freq, ray-parameter and tilt of the good
    %events at a station
    OUTPUT_baz = [];
    OUTPUT_az = [];
    OUTPUT_rayp = [];
    OUTPUT_freq = [];
    OUTPUT_tilt = [];
    theta_grid = [];
    Vs_grid = [];
    %OUTPUT_evdp = [];
    %OUTPUT_dist = [];
    %loop over all events and look for "good" ones
    for j = 1:size(EVENTS,1);

            % Get waveform
            ind_event = strcmp(EVENTS(j),STA_DATA(:,1));
            EVENT_DATA = STA_DATA(ind_event,:);

            indz = strcmp('z',EVENT_DATA(:,3));
            indr = strcmp('r',EVENT_DATA(:,3));
            
            rayp = EVENT_DATA{indz,5};
            baz = EVENT_DATA{indz,10};
            az = mod(baz + 180, 360); %calculates the azimuth
            %evdp = EVENT_DATA{indz,11};
            %dist = EVENT_DATA{indz,12}; %this distance is in degree
            %dist_km = deg2km(dist);

            result_file = strcat('/',STAS(i),'_Vs_freq_results.mat');
            result_filename = char(result_file);
            result_path = '/depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/RESULTS/Twin_1';
            result_filepath = fullfile(result_path,result_filename);
            load(result_filepath);

            status = Vs_solns(j,6);
            freq = Vs_solns(j,7);
            theta_ev = Vs_solns(j,4);
            Vs_ev = Vs_solns(j,5);
            if status == 1; %this checks if it is a good event
                OUTPUT_baz = [OUTPUT_baz, baz];
                OUTPUT_az = [OUTPUT_az, az];
                OUTPUT_rayp = [OUTPUT_rayp, rayp];
                OUTPUT_freq = [OUTPUT_freq, freq];
                theta_grid = [theta_grid, theta_ev];
                Vs_grid = [Vs_grid, Vs_ev];
            else
                disp('This is a bad event')

            end

     
            OUTPUT_tilt = [OUTPUT_tilt, tilt];
            %OUTPUT_evdp = [OUTPUT_evdp, evdp];
            %OUTPUT_dist = [OUTPUT_dist, dist_km];
    end
    theta_grid = theta_grid';
    Vs_grid = Vs_grid'

    %looping over all good events
    for k = 1:length(OUTPUT_az);
        rayp = OUTPUT_rayp(k:k); %gets the rayp for the kth event
        az = OUTPUT_az(k:k); %gets the az for the kth event
        tilt = OUTPUT_tilt(k:k); %gets the tilt for the kth event
        freq = OUTPUT_freq(k:k); %gets the event depth for the kth event
        %dist = OUTPUT_dist(k:k); %gets the distance for the kth event

        %get theta grid (polarization angle) and estimated Vs
        theta_bar = abs(theta_grid(k,1));
        Vs = Vs_grid(k,1);

        %calculate theta(incident angle)
        q = (1/Vs)*sind((theta_bar + tilt)/2); %from eqn 35 (Park et al 2024)
        theta = asind(sqrt(1/(((q - rayp*cosd(tilt))/(rayp*sind(tilt)))^2+1))); %this uses equation 34 and replacing v by sin(theta)/p (Park et al 2024)
        
        z = [0,0,1]; %define the vertical(downward)
        
        %calculate m (eqn 3 in Park et al 2024)
        m_sqr = (sind(theta)*sind(az-(updip)))^2 + (cosd(theta)*sind(tilt) + sind(theta)*cosd(az-(updip))*cosd(tilt))^2;
        m = sqrt(m_sqr);

        %calculate R (eqn 7 in Park et al 2024)
        R = (1/m)*[cosd(theta)*sind(tilt)*cosd(tilt)+sind(theta)*cosd(az-(updip))*(cosd(tilt))^2, -sind(theta)*sind(az-(updip))*cosd(tilt), m*sind(tilt); sind(theta)*sind(az-(updip)), cosd(theta)*sind(tilt)+sind(theta)*cosd(az-(updip))*cosd(tilt), 0;
                    -cosd(theta)*(sind(tilt))^2 - sind(theta)*cosd(az-(updip))*sind(tilt)*cosd(tilt), sind(theta)*sind(az-(updip))*sind(tilt), m*cosd(tilt)];
        
        %calculate polarization angle and polarization vector (in rotated frame) 
        theta_app_rot = 2*asind((1/vel_ratio)*m);
        Mp = [sind(theta_app_rot);0;-cosd(theta_app_rot)];
        
        %rotate back to sensor frame and calculate final polarization angle
        Rot_Mp = R*Mp; %eqn 17
        theta_app = acosd(dot(Rot_Mp,-z')); %eqn 18

        %calculate the corrected velocity
        %Vs_notilt = sind(theta_app/2)/(rayp);

        Vs_notilt = sind(theta_app/2)/(sind(theta)/Vp_true);
            
        error = (Vs_notilt - Vs_true)/Vs_true;
        

        %correct the velocity
        Vs_corr = Vs-(error);

        %calculates the wavelength
        lambda = Vs/freq;
    
    
        %output
        result(k,1) = az;
        result(k,2) = Vs_notilt;
        result(k,3) = error;
        result(k,4) = theta;
        result(k,5) = lambda;
        result(k,6) = freq;
        result(k,7) = Vs;
        result(k,8) = Vs_corr;
    end

    %run statistical test to check the scatter (coefficient of variation)
    var_notilt = var(result(:,2));
    std_notilt = std(result(:,2));

    var_tilt = var(Vs_grid);
    std_tilt = std(Vs_grid);

    cv_notilt = std_notilt / mean(result(:,2));
    cv_tilt = std_tilt / mean(Vs_grid);
    
    % Display the results
    disp(['Coefficient of Variation of Vs-notilt: ', num2str(cv_notilt)]);
    disp(['Coefficient of Variation of Vs-tilt: ', num2str(cv_tilt)]);

    disp(['Variance of Vs-notilt: ', num2str(var_notilt)]);
    disp(['Standard Deviation of Vs-notilt: ', num2str(std_notilt)]);
    
    disp(['Variance of Vs-tilt: ', num2str(var_tilt)]);
    disp(['Standard Deviation of Vs-tilt: ', num2str(std_tilt)]);

    


    %plotting
    figure(1);
    scatter(result(:,1), result(:,8),'r','filled');
    hold on
    scatter(result(:,1), Vs_grid,'b','filled');
    hold on
    set(gca, 'YColor', 'k')
    xline(strike, '--r','Linewidth',1.5)
    xline(mod((strike+180),360), '--r','Linewidth',1.5)
    ylabel('Vs');
    xlabel('Azimuth');
    legend('Vs-corr', 'Vs-flat');
    xlim([0, 360]);
    ylim([-1, 4.5])
    text(10,4.3, ['Dip angle: ' num2str(abs(tilt))], 'FontSize', 10);
    %text(150,4.3, ['CV-notilt: ' num2str(cv_notilt)], 'FontSize', 10);
    %text(150,4.1, ['CV-tilt: ' num2str(cv_tilt)], 'FontSize', 10);
    title(strcat('Shear wave velocity VS azimuth','-',STAS(i)));
    
    %save plot
    figname = strcat('./',figuresfolder,'/','2.0_',STAS(i),'_Vs_topo.pdf')
    saveas(gcf,char(figname),'pdf');

    %figure(2);
    %histogram(result(:,4));
    %xlabel('theta')
    %ylabel('Counts')
   
    %figure(3);
    %boxplot([result(:,7),result(:,8)],'Labels',{'Vs-flat','Vs-corr'})
    
    %save plot
    %figname2 = strcat('./',figuresfolder,'/',STAS(i),'_topo_boxplot.png')
    %saveas(gcf,char(figname2),'png');

    figure(4);
    scatter(result(:,1), result(:,3)*100,'k','Linewidth',2);
    hold on
    plot(output_test(:,1), output_test(:,2)*100,'r','Linewidth',2);
    ylabel('Inferred error');
    xlabel('Azimuth');
    figname3 = strcat('./',figuresfolder,'/','2.0_',STAS(i),'_Vs_error.pdf')
    saveas(gcf,char(figname3),'pdf');
   
    %Save results
    fid = strcat('./',outputfolder,'/','2.0_',STAS(i),'_Vs_topo.mat');
    save(char(fid),'result');
    clear result;
    close all;

end

