
function taper_wf = time_taper(time_series,dt,taper_mins)

nsamp = (taper_mins*60/dt);
tap = hann(nsamp*2); % Get full taper to be split
tap_beg = tap(1:nsamp+1);
tap_end = tap(length(tap)-nsamp:length(tap));

hann_taper = zeros(1,length(time_series))+1;
hann_taper(1:nsamp+1) = tap_beg;
hann_taper(length(hann_taper)-nsamp:length(hann_taper)) = tap_end;

taper_wf = time_series.*hann_taper;

end