%%F-test 
clear all; close all;

outputfolder = sprintf('2.0_STATS_tests'); % Make this if it does not exist
directory = '/depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/PMA_Method/TOPO/RESULTS/TOPO_corrections';

fid = fopen('/depot/jdelph/data/INASHUA/Sunny_package/Sunny_Algorithm/TOPO/RESULTS_NEW/good_station_list.txt');
stations = textscan(fid, '%s');
fclose(fid);
stations = stations{1}


%Output = zeros(0, 1);
%Output_Sta = cell(0, 1);
for i = 1;%1:length(stations);
    filename = ['2.0_',stations{i},'_Vs_notilt_depth.mat'];
    %file_str = strsplit(filename, '/');
    %datafile = file_str{11};
    %datafile_str = strsplit(datafile, '_')
    %station = station{i};
    data = load(fullfile(directory,filename));
    sort_data = sortrows(data.Output,4)
    Vs = sort_data(:, 1);
    depth = sort_data(:, 4);
    freq = sort_data(:, 2);

    %% Define the model functions and fit
    % Define Models and Initial Guesses
 
    model1 = @(a,x) 0 .* x + a; %linear model (null hypothesis)
    guess1 = [1];
    model2 = @(b,x) b(1) .* log(x) + b(2);
    %model2 = @(b,x) b(1) .* x + b(2);
    guess2 = [1 1];

    % Determine values of the parameters using nlinfit
    [alpha,R1,J1,CovB1,MSE1] = nlinfit(depth,Vs,model1, guess1);
    [beta,R2,J2,CovB2,MSE2] = nlinfit(depth,Vs,model2,guess2);
    %fit_object = fitnlm(depth,Vs,model2,guess2);
    %beta = fit_object.Coefficients.Estimate;
    %MSE2 = fit_object.MSE;
    %CovB2 = fit_object.CoefficientCovariance;
    %R2 = fit_object.Residuals.Raw;

    


    %% Compare fits to see which is better
    % Compute sum of squares for each model and the total sum of squares
    ssmodel1=sum(R1.^2);
    ssmodel2=sum(R2.^2);
    sstotal=sum((Vs-mean(Vs)).^2);
    % Calculate r^2 for each model
    r2model1=1-ssmodel1./sstotal;
    r2model2=1-ssmodel2./sstotal;
    % Calculate the F statistic, The null hypothesis (that model 1 is simpler) is rejected if the F
    % calculated from the data is greater than the critical value of the
    % F-distribution for some desired false-rejection probability (e.g. 0.05)
    
    df1=length(Vs)-1;
    df2=length(Vs)-2;
    F=((ssmodel1 - ssmodel2)/(df1-df2))/(ssmodel2/df2);
    P=1-fcdf(F,df1,df2);

    P_value = P;
    
    
    if P_value <= 0.05
        result = 1;
    else
        result = 0;
    end

    output(i,1) = P_value;
    output(i,2) = result;
    output(i,3) = beta(1);

    %get data from Wang model
    %load("Wang_avg_Vs_profile.mat");
    
    %station_vs = OUTPUT(125,:); %125 for A30 and 81 for A22
    %wang_vs = (station_vs(1,2:end))';
    %wang_depth = (linspace(1,15,15))';

    

    %% Plot models with raw data
    N1=(0*depth + alpha(1));
    N2=beta(1) * log(depth) + beta(2);
    %N2=beta(1) * depth + beta(2);
    x=linspace(0,10,1000);
    figure;
    plot(depth,Vs,'ok')
    hold on
    plot(depth,N1,'--r')
    hold on
    plot(depth,N2,'-b')
    hold on;
    %plot(wang_depth, wang_vs, 'k','Linewidth',1)
    hold on;
    x_position = 20;

    % Store current axis properties before boxplot
    ax = gca;
    xticks_original = ax.XTick;  % Save original x-axis ticks
    xticklabels_original = ax.XTickLabel;  % Save original x-axis labels

    boxplot(Vs, 'Positions', x_position, 'Widths', 1.5);
    
    % Restore original axis properties
    ax.XTick = xticks_original;  % Reset x-axis ticks
    ax.XTickLabel = xticklabels_original;  % Reset x-axis labels

    xlabel('Depth (km)','FontSize',14)
    ylabel('Vs(km/s)','FontSize',14)
    xlim([0, 22])
    ylim([0, 5])
    set(gca, 'YDir', 'reverse');
    set(gca, 'XAxisLocation', 'top');
    title('Depth vs Vs','FontSize',16)
    legend({'Data','Linear','Exponential'},'Location','southeast')
    hold on
    text(8,1, ['P-value: ' num2str(P)], 'FontSize', 12)

    %SAVING PLOT

    fid2 = strcat('./',outputfolder,'/',filename,"_F-test",'.pdf')
    saveas(gcf,char(fid2),'pdf');

    close all;



    
end
%SAVE RESULTS
fid3 = strcat('2.0_F-test.mat');
save(char(fid3),'output');

%% 
%convert to txt
load("2.0_F-test.mat");
    
    fid4 = strcat('2.0_F-test','.txt');
    save (char(fid4), 'output', '-ascii')